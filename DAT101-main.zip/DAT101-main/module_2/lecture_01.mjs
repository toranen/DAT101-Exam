
import { initPrintOut, printOut, newLine } from "../../common/script/utils.mjs";
initPrintOut(document.getElementById("txtOut"));
"use strict"

let v1 = 2;
const v2 = "Dette er en tekst";
const v3 = 1.56732;
const v4 = 12;
let v5 = 13;

v2 = "Dette er en ny tekst!";

printOut("Programmet er ferdig!");